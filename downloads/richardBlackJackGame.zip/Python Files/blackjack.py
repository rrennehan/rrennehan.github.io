import random
import time
import sys
fileName = "blackjackleaderboard.txt"


print("♠♥♦♣ Welcome to BlackJack ♣♦♥♠")
print()
print("We'll start you off with a balance of 1000")
userBalance = 1000
print()
print("You will choose how much to bet each round. You will face the dealer each round.")
print("If you get a higher total than the dealer you win! However, go over 21 and you lose.")
print("If you win, you get the amount of your bet plus an extra 1/5 back.")
print("A blackjack will get you the amount of your bet plus an extra 1/2!")
print("Don't forget, you can stop at anytime. Try to set a new high score.")
print()
startOrHelp = input("Press ENTER when you are ready to begin").lower()
if startOrHelp == "help":
    print()
print()

def create52cards():
    suits = ["Spades", "Clubs", "Hearts", "Diamonds"]
    values = [2, 3, 4, 5, 6, 7, 8, 9, 10, "Jack", "Queen", "King", "Ace"]
    listOfCards = []
    for value in values:
        for suit in suits:
            card = []
            card.append(value)
            card.append(suit)
            listOfCards.append(card)
    return listOfCards

def usergetcard(list):
    if list == userDummyHand:
        userCards.append(list[0])
        userCards.append(list[1])
        return userCards

    import random
    cardSelected = list.pop(random.randint(0, len(listOfCards) - 1))
    userCards.append(cardSelected)
    return userCards

def dealergetcard(list):
    if list == dealerDummyHand:
        dealerCards.append(list[0])
        dealerCards.append(list[1])
        return dealerCards
    import random
    cardSelected = list.pop(random.randint(0, len(listOfCards) - 1))
    dealerCards.append(cardSelected)
    return dealerCards

def displayCards(cards):
    if cards == userCards:
        message = "\nYour cards:"
        for counter, card in enumerate(cards):
            if counter == 0:
                message += " {} of {}".format(card[0], card[1])
            else:
                message += ", {} of {}".format(card[0], card[1])

        print(message + " (total is {})".format(userTotal))
        return message
    elif cards == dealerCards:
        message = "\nDealer's cards:"
        for counter, card in enumerate(cards):
            if counter == 0:
                message += " {} of {}".format(card[0], card[1])
            else:
                message += ", {} of {}".format(card[0], card[1])
        print(message + " (total is {})".format(dealerTotal))
        return message

def calculateTotal(cards):
    total = 0
    if cards == userCards:

        for card in cards:
            if card[0] == "Jack" or card[0] == "Queen" or card[0] == "King":
                value = 10
            elif card[0] == "Ace":
                value = 11
            else:
                value = card[0]

            total += value

        if total > 21:
            for card in cards:
                if card[0] == "Ace":
                    total -= 10
                if total <= 21:
                    break

        return total

    elif cards == dealerCards:

        for card in cards:
            if card[0] == "Jack" or card[0] == "Queen" or card[0] == "King":
                value = 10
            elif card[0] == "Ace":
                value = 11
            else:
                value = card[0]

            total += value

        if total > 21:
            for card in cards:
                if card[0] == "Ace":
                    total -= 10
                if total <= 21:
                    break
        return total

def saveScore():
    try:
        with open(fileName, "r") as leaderboards:
            while True:
                username = input("Please enter your name: ")
                if len(username) > 13:
                    print("\nYour name cannot exceed 13 characters.")
                else:
                    break
            scores = []
            leaderboards.readline()
            leaderboards.readline()  # Skip the first two lines
            scoresFile = leaderboards.readlines()
            for line in scoresFile:
                name = line[4:18]  # Starts at the fifth character. Does not include anything after the 18th character
                score = line[18:25]
                score = [name, "{:>7}".format(score)]
                scores.append(score)
            userScore = [username, str(userBalance)]
            scores.append(userScore)
            scores.sort(key=lambda x: int(x[-1]), reverse=True)

        with open(fileName, "w+") as leaderboards:
            leaderboards.write("  Blackjack Leaderboard\n")  # Header
            leaderboards.write("-------------------------\n")
            for counter, score in enumerate(scores, 1):
                leaderboards.write("{:>4}{:<14}{:>7}\n".format(str(counter) + ". ", score[0], score[1]))

        return True

    except FileNotFoundError:
        print("\nThe leaderboards file could not be found. Make sure the leaderboards file is in the same location")
        print("as the blackjack file")


def displayLeaderboards():
    try:
        with open(fileName, "r") as leaderboards:
            displayLeaders = leaderboards.read()
            print()
            print(displayLeaders)
    except FileNotFoundError:
        print("\nThe leaderboards file could not be found. Make sure the leaderboards file is in the same location")
        print("as the blackjack file")



listOfCards = create52cards()
userDummyHand = [["Ace", "hearts"], ["Jack", "clubs"]]
dealerDummyHand = [["Ace", "clubs"], [4, "spades"]]


print("Your current balance is {:.0f}".format(userBalance))
while True: #Game starts from here
    userCards = []
    dealerCards = []

    if len(listOfCards) <= 26:
        print("\nThe cards will now be reshuffled\n")
        time.sleep(2)
        listOfCards = create52cards() #Reshuffle

    dealergetcard(listOfCards)
    print("\nThe dealer's first card is: {} of {}".format(dealerCards[0][0], dealerCards[0][1]))

    while True: #Process for checking validity of bet
        try:
            userBet = input("\nHow much would you like to bet?: ")
            userBet = int(userBet)
            if userBet > userBalance:
                print("\nYou can't bet more than you have!\n")
            elif userBet < 0:
                print("\nYou can't bet a negative amount. Nice try!")
            elif userBet == 0:
                print("\nYou can't bet nothing. Nice try!")
            else:
                break
        except:
            print("\nInvalid input. Try again.")

    if str(userBet).lower() == "quit":
        break


    usergetcard(listOfCards)
    usergetcard(listOfCards)


    userTotal = calculateTotal(userCards)
    hitOrStay = "hit"

    while userTotal < 21:
        displayCards(userCards)
        while True:
            hitOrStay = input("Hit or stand?: ").lower()
            if hitOrStay != "hit" and hitOrStay != "stand":
                print("\nYou must enter either hit or stand")
            else:
                break

        if hitOrStay == "hit":
            usergetcard(listOfCards)
            userTotal = calculateTotal(userCards)
        elif hitOrStay == "stand":
            break


    if hitOrStay == "hit":

        displayCards(userCards)
        if userTotal == 21:
            if len(userCards) == 2:
                time.sleep(1)
                print("Blackjack! You just earned {:.0f}!".format(userBet * 1.5))
                userBalance += userBet * 1.5
            else:
                print("21! You earned {:.0f}!".format(userBet * 1.2))
                userBalance += userBet * 1.2
        elif userTotal > 21:
            print("Bust! Your total was {}. You lose {:.0f}".format(userTotal, userBet))
            userBalance -= userBet

    elif hitOrStay == "stand":
        print("\nIt is now the dealer's turn.")
        time.sleep(1)
        dealerTotal = calculateTotal(dealerCards)
        while dealerTotal < 17 and dealerTotal <= userTotal:
            displayCards(dealerCards)
            dealergetcard(listOfCards)
            dealerTotal = calculateTotal(dealerCards)
            time.sleep(1)

        displayCards(dealerCards)
        time.sleep(1)

        if dealerTotal == 21:
            print("The dealer got a 21. You lose {:.0f}.".format(userBet))
            userBalance -= userBet
        elif dealerTotal > 21:
            print("The dealer busted. You earned {:.0f}!".format(userBet * 1.2))
            userBalance += userBet * 1.2
        else:
            if dealerTotal > userTotal:
                print("The dealer beat you. You lose {:.0f}.".format(userBet))
                userBalance -= userBet
            elif dealerTotal < userTotal:
                print("The dealer got a lower total. You earned {:.0f}!".format(userBet * 1.2))
                userBalance += userBet * 1.2
            elif dealerTotal == userTotal:
                print("You tied with the dealer.")

    userBalance = int(userBalance)

    if userBalance == 0:
        break

    print("\nYour current balance is {:.0f}".format(userBalance))

    while True:
        playAgain = input("Would you like to continue playing [yes/no]?: ").lower()
        if playAgain != "yes" and playAgain != "no":
            print("You must enter either yes or no")
        else:
            break

    if playAgain == "yes":
        continue
    elif playAgain == "no":
        break




if userBalance == 0: #Ending number 1
    print("\nYour balance is 0. Game over.")
    print("Thanks for playing!")
    print("\nHere are the top scores:")
    time.sleep(2)
    displayLeaderboards()
    input()


else: #Ending number 2
    print("\nThanks for playing!")
    print("Your score is {:.0f}".format(userBalance))
    time.sleep(1)

    while True:
        save = input("\nWould you like to save your score to the leaderboard [yes/no]?: ").lower()
        if save == "yes":
            if saveScore() == True:
                print("\nYour score has been saved successfully!")
                displayLeaderboards()
            input()
            break
        elif save == "no":
            print("\nHere are the top scores:")
            time.sleep(1)
            displayLeaderboards()
            input()
            break
        else:
            print("\nYou must enter either yes or no")


'''
What I'll need to do
Fix hit or stay to hit or stand
Dealer is supposed to show the first card from the start
Decide whether to make this a gui game. Perhaps have achievements
Finish the extended blackjack instructions.
'''
