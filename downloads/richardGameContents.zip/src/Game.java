/*File Structure:
 *
 *  Blueprint variables for this class
 *  Additional variables created, like image lists and files
 *  Declaring each JPanel Screen
 *  Placing specific GUI elements up front to avoid not declared errors
 *  Methods for code to be repeated, such as monster's turn, loading the battle prep screen, etc.
 *  Character selection screen attributes and actions
 *  Battle screen attributes and actions
 *  Shop screen attributes and actions
 *  Battle Prep screen attributes and actions
 *  Title screen attributes and actions
 */

//I do not own any art displayed in the game. All artwork belongs to their respective owners.

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class Game extends JFrame {
	
	Hero hero; //Declaring hero now so works across entire program
	Monster monster; //Like with hero, we'll define it later
	int level = 1; //Round number for game
	int battleRound = 1;
	private JPanel contentPane;
	private final ButtonGroup buttonGroupSelectCharacter = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private final ButtonGroup buttonGroup_2 = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Game frame = new Game();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public Game() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 690, 452);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		//Initialize variables for game
		
		Random rand = new Random();
		String[] heroFiles = {"knight.jpg", "Archer.jpg", "Wizard.jpg"}; //file names for hero images
		Icon[] heroImages = //icon list for hero images
		{
			new ImageIcon(Game.class.getResource(heroFiles[0])),
			new ImageIcon(Game.class.getResource(heroFiles[1])),
			new ImageIcon(Game.class.getResource(heroFiles[2]))
		};
		
		int[] monsterCount = {0, 0, 0}; //To count how much of each monster we have summoned
		
		String[] monsterFiles = {"spider.jpg", "werewolf.jpg", "demonbear.jpg"}; //file names for monster images
		Icon[] monsterImages = //icon list for monster images
			{
					new ImageIcon(Game.class.getResource(monsterFiles[0])),
					new ImageIcon(Game.class.getResource(monsterFiles[1])),
					new ImageIcon(Game.class.getResource(monsterFiles[2]))
			};
		
		String[] tips = {"Tip: Don't forget to upgrade your hero after each battle. You earn 1 upgrade point for each victory",
				"Tip: Geoff Gillespie is a pretty cool guy. Don't mess with him!",
				"Tip: Stuck? Don't forget to use your gold to buy healing and assist items.",
				"Tip: Try all the heroes out! Each feels very different",
				"Tip: It's a good idea to read tips",
				"Fun fact: I spent around 20 hours making this game for a programming assignment!",
				"Tip: You only have 3 lives. If you lose all 3, you start from the beginning",
				"Tip: If you are defeated in battle, you get sent back to the monster fought last round"
		};
		
		
		//Declaring each JPanel Screen
		
		
		JPanel titleScreen = new JPanel();
		contentPane.add(titleScreen, "name_101906880135236");
		titleScreen.setLayout(null);
		
		JPanel selectScreen = new JPanel();
		contentPane.add(selectScreen, "name_101909221992858");
		selectScreen.setLayout(null);
		
		JPanel prepScreen = new JPanel();
		contentPane.add(prepScreen, "name_101912414343847");
		prepScreen.setLayout(null);
		
		JPanel shopScreen = new JPanel();
		contentPane.add(shopScreen, "name_11594215126651");
		shopScreen.setLayout(null);
		
		JPanel battleScreen = new JPanel();
		contentPane.add(battleScreen, "name_11620390939010");
		battleScreen.setLayout(null);
		
		//Specific elements that had to be placed up front
		
		JPanel panelBattleButtons = new JPanel();
		panelBattleButtons.setEnabled(false);
		panelBattleButtons.setBounds(66, 216, 152, 151);
		battleScreen.add(panelBattleButtons);
		panelBattleButtons.setLayout(null);
		
		
		JButton btnBattleAttack = new JButton("Attack");
		btnBattleAttack.setBounds(0, 0, 152, 35);
		panelBattleButtons.add(btnBattleAttack);
		
		JButton btnBattleUseItem = new JButton("Use Item");
		btnBattleUseItem.setBounds(0, 75, 152, 35);
		panelBattleButtons.add(btnBattleUseItem);
		
		JButton btnFlee = new JButton("Flee");
		btnFlee.setBounds(0, 116, 152, 35);
		panelBattleButtons.add(btnFlee);
		
		JLabel lblBattleHeroImage = new JLabel("");
		lblBattleHeroImage.setOpaque(true);
		lblBattleHeroImage.setBounds(66, 11, 152, 152);
		battleScreen.add(lblBattleHeroImage);
		
		JLabel lblBattleHeroHealth = new JLabel("Health:");
		lblBattleHeroHealth.setOpaque(true);
		lblBattleHeroHealth.setBounds(66, 163, 152, 21);
		battleScreen.add(lblBattleHeroHealth);
		
		JLabel lblBattleMonsterImage = new JLabel("");
		lblBattleMonsterImage.setOpaque(true);
		lblBattleMonsterImage.setBounds(442, 11, 152, 152);
		battleScreen.add(lblBattleMonsterImage);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setAutoscrolls(true);
		scrollPane.setBounds(260, 290, 361, 105);
		battleScreen.add(scrollPane);
		
		JTextArea textAreaBattleDialog = new JTextArea();
		scrollPane.setViewportView(textAreaBattleDialog);
		textAreaBattleDialog.setWrapStyleWord(true);
		textAreaBattleDialog.setLineWrap(true);
		textAreaBattleDialog.setEditable(false);
		
		JLabel lblPrepHeroImage = new JLabel("");
		lblPrepHeroImage.setOpaque(true);
		lblPrepHeroImage.setBounds(31, 244, 152, 152);
		prepScreen.add(lblPrepHeroImage);
		
		JPanel panelPrepHeroStats = new JPanel();
		panelPrepHeroStats.setName("Hero Stats");
		panelPrepHeroStats.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Hero Stats", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panelPrepHeroStats.setBounds(35, 51, 136, 188);
		prepScreen.add(panelPrepHeroStats);
		panelPrepHeroStats.setLayout(null);
		
		JLabel lblPrepHeroLevel = new JLabel("Knight: Level 2");
		lblPrepHeroLevel.setBounds(6, 16, 124, 34);
		panelPrepHeroStats.add(lblPrepHeroLevel);
		lblPrepHeroLevel.setOpaque(true);
		lblPrepHeroLevel.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JLabel lblPrepHeroHealth = new JLabel("Health: ");
		lblPrepHeroHealth.setBounds(6, 47, 124, 34);
		panelPrepHeroStats.add(lblPrepHeroHealth);
		lblPrepHeroHealth.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblPrepHeroHealth.setOpaque(true);
		
		JLabel lblPrepHeroBaseAttack = new JLabel("Base Attack: ");
		lblPrepHeroBaseAttack.setBounds(6, 79, 124, 34);
		panelPrepHeroStats.add(lblPrepHeroBaseAttack);
		lblPrepHeroBaseAttack.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblPrepHeroBaseAttack.setOpaque(true);
		
		JLabel lblPrepHeroSpeed = new JLabel("Speed:");
		lblPrepHeroSpeed.setBounds(6, 110, 124, 34);
		panelPrepHeroStats.add(lblPrepHeroSpeed);
		lblPrepHeroSpeed.setOpaque(true);
		lblPrepHeroSpeed.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JLabel lblPrepHeroCritChance = new JLabel("Critical Chance: ");
		lblPrepHeroCritChance.setBounds(6, 143, 124, 34);
		panelPrepHeroStats.add(lblPrepHeroCritChance);
		lblPrepHeroCritChance.setOpaque(true);
		lblPrepHeroCritChance.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JLabel lblPrepItem = new JLabel("Currently Holding: ");
		lblPrepItem.setVisible(false);
		lblPrepItem.setOpaque(true);
		lblPrepItem.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblPrepItem.setBounds(188, 275, 162, 34);
		prepScreen.add(lblPrepItem);
		
		JLabel lblPrepMonsterImage = new JLabel("");
		lblPrepMonsterImage.setOpaque(true);
		lblPrepMonsterImage.setBounds(506, 63, 152, 152);
		prepScreen.add(lblPrepMonsterImage);
		
		JPanel panelPrepMonsterStats = new JPanel();
		panelPrepMonsterStats.setLayout(null);
		panelPrepMonsterStats.setName("Hero Stats");
		panelPrepMonsterStats.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Next Monster:", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panelPrepMonsterStats.setBounds(360, 78, 136, 125);
		prepScreen.add(panelPrepMonsterStats);
		
		JLabel lblPrepMonsterLevel = new JLabel("Spider: Level 1");
		lblPrepMonsterLevel.setOpaque(true);
		lblPrepMonsterLevel.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblPrepMonsterLevel.setBounds(6, 16, 124, 34);
		panelPrepMonsterStats.add(lblPrepMonsterLevel);
		
		JLabel lblPrepMonsterHealth = new JLabel("Health: ");
		lblPrepMonsterHealth.setOpaque(true);
		lblPrepMonsterHealth.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblPrepMonsterHealth.setBounds(6, 47, 124, 34);
		panelPrepMonsterStats.add(lblPrepMonsterHealth);
		
		JLabel lblPrepMonsterBaseAttack = new JLabel("Base Attack: ");
		lblPrepMonsterBaseAttack.setOpaque(true);
		lblPrepMonsterBaseAttack.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblPrepMonsterBaseAttack.setBounds(6, 79, 124, 34);
		panelPrepMonsterStats.add(lblPrepMonsterBaseAttack);
		
		JTextArea textareaPrepTips = new JTextArea();
		textareaPrepTips.setEditable(false);
		textareaPrepTips.setText("Tip: If you're feeling lucky, try defending during a battle. If successful, you attack twice in a row!");
		textareaPrepTips.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textareaPrepTips.setLineWrap(true);
		textareaPrepTips.setWrapStyleWord(true);
		textareaPrepTips.setBounds(0, 0, 664, 37);
		prepScreen.add(textareaPrepTips);
		
		//Specific methods for reusing code
		
		ActionListener loadPrepScreen = new ActionListener() 
		{
			public void actionPerformed(ActionEvent event) 
			{
					
					//Set up prep screen
				if(level == 1)
				{
					monster = new Monster(1, 30, 30, 5, "Giant Spider", 15); //Create first monster
				}
				else if(level == 2)
				{
					monster = new Monster(1, 50, 50, 20, "Werewolf", 50);
				}
				else if(level >= 3)
				{
					monster = new Monster(1, 100, 100, 25, "Demon Bear", 75);
				}
				lblPrepHeroLevel.setText(hero.getCurrentHero() + ": Level " + hero.getLevel());
				lblPrepHeroHealth.setText("Health: " + hero.getCurrentHealth() + "/" + hero.getMaxHealth());
				lblPrepHeroBaseAttack.setText("Attack Range: " + hero.getBaseAttack(-5) + "-" + hero.getBaseAttack(5));
				lblPrepHeroSpeed.setText("Speed: " + hero.getSpeed());
				lblPrepHeroCritChance.setText("Critical Chance: " + hero.getCritChance() + "%");
				lblPrepMonsterLevel.setText(monster.getCurrentMonster() + ": Level " + monster.getLevel());
				lblPrepMonsterHealth.setText("Health: " + monster.getCurrentHealth() + "/" + monster.getMaxHealth());
				lblPrepMonsterBaseAttack.setText("Attack Range: " + monster.getBaseAttack(-5) + "-" + monster.getBaseAttack(5));
				
				for(int i=0; i<3; i++)
				{
					if(monster.getCurrentMonster().equals(monster.getMonsterTypes()[i]))
					{
						lblPrepMonsterImage.setIcon(monsterImages[i]);
						lblBattleMonsterImage.setIcon(monsterImages[i]);
					}
					if(hero.getCurrentHero().equals(hero.getHeroNames()[i]))
					{
						lblPrepHeroImage.setIcon(heroImages[i]);
						lblBattleHeroImage.setIcon(heroImages[i]);
					}
				}
				
				if(hero.getItem() != null)
				{
					if(hero.getItem().getItemName() == "apple")
						lblPrepItem.setText("Currently Holding: Apple");
					lblPrepItem.setVisible(true);
				}
				else
				{
					lblPrepItem.setVisible(false);
				}
				textareaPrepTips.setText(tips[rand.nextInt(tips.length)]);
			}
		};
		
		ActionListener monsterTurn = new ActionListener() 
		{
			public void actionPerformed(ActionEvent event) 
			{
				if(monster.getCurrentHealth() <= 0)
				{
					monster.Defeated();
					JOptionPane.showMessageDialog(null, "The monster has been defeated! You earned " + monster.getGoldDrop() + " gold! \n");
					hero.setBalance(hero.getBalance() + monster.getGoldDrop());
					hero.LevelUp();
					level += 1;
					
					Timer timer = new Timer(0, loadPrepScreen);
					timer.setRepeats(false);
					timer.start();
					
					battleScreen.setVisible(false);
					prepScreen.setVisible(true);
					if(level == 4)
					{
						JOptionPane.showMessageDialog(null, "Developer's Note: \n Thanks for playing this demo! All enemies from this point will be demon bears \n of this level.");
					}
				}
				
				else if(!monster.isStunned()) {
					int number = rand.nextInt(100);
					if(number > hero.getSpeed())
					{
						int mondamage = monster.Attack();
						textAreaBattleDialog.append("Ouch! The monster struck you for " + mondamage + " damage! \n");
						hero.setCurrentHealth(hero.getCurrentHealth() - mondamage);
						if(hero.getCurrentHealth()<0)
						{
							hero.setCurrentHealth(0);
						}
						lblBattleHeroHealth.setText("Health: " + hero.getCurrentHealth() + "/" + hero.getMaxHealth());
						if(hero.getCurrentHealth() == 0)
						{
							hero.setLives(hero.getLives() -1);
							if(hero.getLives() != 0) //As long as lives left does not equal 0
							{
								hero.setCurrentHealth(hero.getMaxHealth());
								level -= 1;
								JOptionPane.showMessageDialog(null, "Oh no! You now have " + hero.getLives() + " lives left");
								Timer timer = new Timer(0, loadPrepScreen);
								timer.setRepeats(false);
								timer.start();
								battleScreen.setVisible(false);
								prepScreen.setVisible(true);
							}
							else
							{
								JOptionPane.showMessageDialog(null, "You are out of lives. Game over");
								level = 1;
								battleScreen.setVisible(false);
								titleScreen.setVisible(true);
							}
							
							
							
						}
					}
					
					else {
						textAreaBattleDialog.append("Whoosh! The hero dodges the attack. \n");
					}
				}
				monster.setStunned(false);
				monster.setAttackDebuff(1);
				battleRound += 1;
			}
		};
		
		ActionListener disableBattleButtons = new ActionListener() 
		{
			public void actionPerformed(ActionEvent event) 
			{
				btnBattleAttack.setEnabled(false);
				btnBattleUseItem.setEnabled(false);
				btnFlee.setEnabled(false);
			}
		};
		
		ActionListener enableBattleButtons = new ActionListener() 
		{
			public void actionPerformed(ActionEvent event) 
			{
				btnBattleAttack.setEnabled(true);
				if(hero.getItem() != null)
				{
					btnBattleUseItem.setEnabled(true);
				}
				else
				{
					btnBattleUseItem.setEnabled(false);
				}
				btnFlee.setEnabled(true);
			}
		};
		
		
		//
		//Select Screen (Where our hero is created)
		
		JPanel panelHeroInfo = new JPanel();
		panelHeroInfo.setVisible(false);
		
		panelHeroInfo.setOpaque(false);
		panelHeroInfo.setBounds(293, 79, 312, 214);
		selectScreen.add(panelHeroInfo);
		panelHeroInfo.setLayout(null);
		
		JLabel lblSelectCriticalHitChance = new JLabel("Critical Hit Chance:");
		lblSelectCriticalHitChance.setBounds(154, 104, 157, 38);
		panelHeroInfo.add(lblSelectCriticalHitChance);
		lblSelectCriticalHitChance.setOpaque(true);
		lblSelectCriticalHitChance.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblSelectCriticalHitChance.setBackground(Color.WHITE);
		
		JLabel lblSelectEvadeChance = new JLabel("Evade Chance:");
		lblSelectEvadeChance.setBounds(154, 142, 157, 35);
		panelHeroInfo.add(lblSelectEvadeChance);
		lblSelectEvadeChance.setOpaque(true);
		lblSelectEvadeChance.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblSelectEvadeChance.setBackground(Color.WHITE);
		
		JTextArea textAreaSelectFighterDescription = new JTextArea();
		textAreaSelectFighterDescription.setBounds(0, 0, 312, 105);
		panelHeroInfo.add(textAreaSelectFighterDescription);
		textAreaSelectFighterDescription.setFont(new Font("Tahoma", Font.PLAIN, 16));
		textAreaSelectFighterDescription.setWrapStyleWord(true);
		textAreaSelectFighterDescription.setLineWrap(true);
		textAreaSelectFighterDescription.setEditable(false);
		textAreaSelectFighterDescription.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JLabel lblSelectWeapon = new JLabel("Weapon:");
		lblSelectWeapon.setBounds(0, 176, 156, 38);
		panelHeroInfo.add(lblSelectWeapon);
		lblSelectWeapon.setOpaque(true);
		lblSelectWeapon.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblSelectWeapon.setBackground(Color.WHITE);
		
		JLabel lblSelectHealth = new JLabel("Health: ");
		lblSelectHealth.setBounds(0, 104, 157, 38);
		panelHeroInfo.add(lblSelectHealth);
		lblSelectHealth.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblSelectHealth.setOpaque(true);
		lblSelectHealth.setBackground(Color.WHITE);
		
		JLabel lblSelectBaseAttack = new JLabel("Base Attack:");
		lblSelectBaseAttack.setBounds(0, 142, 157, 38);
		panelHeroInfo.add(lblSelectBaseAttack);
		lblSelectBaseAttack.setOpaque(true);
		lblSelectBaseAttack.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblSelectBaseAttack.setBackground(Color.WHITE);
		
		JLabel lblSelectHeroImage = new JLabel("");
		lblSelectHeroImage.setIcon(null);
		lblSelectHeroImage.setBounds(35, 198, 152, 152);
		selectScreen.add(lblSelectHeroImage);
		
		JPanel panelFighterSelect = new JPanel();
		panelFighterSelect.setToolTipText("");
		panelFighterSelect.setBorder(new TitledBorder(null, "Fighter Select", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelFighterSelect.setBounds(35, 91, 119, 93);
		selectScreen.add(panelFighterSelect);
		panelFighterSelect.setLayout(null);
		
		JRadioButton rdbtnSelectWizard = new JRadioButton("Wizard");
		rdbtnSelectWizard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelHeroInfo.setVisible(true);
				textAreaSelectFighterDescription.setText("A master of magic. Each critical hit plants a random spell on the enemy.");
				lblSelectHeroImage.setIcon(heroImages[2]);
				lblSelectHealth.setText("Health: 90");
				lblSelectBaseAttack.setText("Base Attack: 15");
				lblSelectCriticalHitChance.setText("Critical Hit Chance: 30%");
				lblSelectEvadeChance.setText("Evade Chance: 5%");
				lblSelectWeapon.setText("Weapon: Staff");
			}
		});
		buttonGroupSelectCharacter.add(rdbtnSelectWizard);
		rdbtnSelectWizard.setBounds(6, 64, 109, 23);
		panelFighterSelect.add(rdbtnSelectWizard);
		
		JRadioButton rdbtnSelectArcher = new JRadioButton("Archer");
		rdbtnSelectArcher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panelHeroInfo.setVisible(true);
				textAreaSelectFighterDescription.setText("Quick and agile. Has least amount of health but strong damage. Most likely to avoid enemy attacks");
				lblSelectHeroImage.setIcon(heroImages[1]);
				lblSelectHealth.setText("Health: 50");
				lblSelectBaseAttack.setText("Base Attack: 20");
				lblSelectCriticalHitChance.setText("Critical Hit Chance: 40%");
				lblSelectEvadeChance.setText("Evade Chance: 30%");
				lblSelectWeapon.setText("Weapon: Bow");
			}
		});
		buttonGroupSelectCharacter.add(rdbtnSelectArcher);
		rdbtnSelectArcher.setBounds(6, 40, 109, 23);
		panelFighterSelect.add(rdbtnSelectArcher);
		
		JRadioButton rdbtnSelectKnight = new JRadioButton("Knight");
		rdbtnSelectKnight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelHeroInfo.setVisible(true);
				textAreaSelectFighterDescription.setText("A strong, well-balanced fighter. Courageous and determined. Best for those who like predictability");
				lblSelectHeroImage.setIcon(heroImages[0]);
				lblSelectHealth.setText("Health: 120");
				lblSelectBaseAttack.setText("Base Attack: 15");
				lblSelectCriticalHitChance.setText("Critical Hit Chance: 10%");
				lblSelectEvadeChance.setText("Evade Chance: 15%");
				lblSelectWeapon.setText("Weapon: Sword");
			}
		});
		buttonGroupSelectCharacter.add(rdbtnSelectKnight);
		rdbtnSelectKnight.setBounds(6, 16, 109, 23);
		panelFighterSelect.add(rdbtnSelectKnight);
		
		JLabel lblSelectChooseYourCharacter = new JLabel("Choose Your Character");
		lblSelectChooseYourCharacter.setFont(new Font("Freestyle Script", Font.PLAIN, 40));
		lblSelectChooseYourCharacter.setOpaque(true);
		lblSelectChooseYourCharacter.setBackground(Color.GRAY);
		lblSelectChooseYourCharacter.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelectChooseYourCharacter.setBounds(0, 5, 664, 52);
		selectScreen.add(lblSelectChooseYourCharacter);
		
		JButton btnImReady = new JButton("I'm Ready!");
		btnImReady.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(buttonGroupSelectCharacter.getSelection()==null) //No fighter picked
				{
					JOptionPane.showMessageDialog(null, "Not so fast! You must select a fighter");
				}
				else
				{
					//if else process creates hero based on selection 
					if(rdbtnSelectKnight.isSelected())
					{
					hero = new Hero(1, 120, 120, 15, "Knight", 15, 10);
					}
					else if(rdbtnSelectArcher.isSelected())
					{
						hero = new Hero(1, 50, 50, 20, "Archer", 30, 40);
					}
					else if(rdbtnSelectWizard.isSelected())
					{
						hero = new Hero(1, 90, 90, 15, "Wizard", 5, 30);	
					}
					
					selectScreen.setVisible(false);
					
					
					//Set up prep screen
					
					Timer timer = new Timer(0, loadPrepScreen);
					timer.setRepeats(false);
					timer.start();
					
					prepScreen.setVisible(true);
					
				}
			}
		});
		btnImReady.setBounds(486, 321, 119, 23);
		selectScreen.add(btnImReady);
		
		JLabel lblSelectBackground = new JLabel("");
		lblSelectBackground.setBounds(-212, 11, 900, 639);
		lblSelectBackground.setIcon(new ImageIcon(Game.class.getResource("background.jpg")));
		selectScreen.add(lblSelectBackground);
		
		
		//Battle Screen
		
		JLabel lblBattleMonsterHealth = new JLabel("Health:");
		lblBattleMonsterHealth.setOpaque(true);
		lblBattleMonsterHealth.setBounds(442, 163, 152, 21);
		battleScreen.add(lblBattleMonsterHealth);
		
		JTextArea textAreaBattleDescription = new JTextArea();
		textAreaBattleDescription.setEditable(false);
		textAreaBattleDescription.setFont(new Font("Tahoma", Font.PLAIN, 16));
		textAreaBattleDescription.setLineWrap(true);
		textAreaBattleDescription.setWrapStyleWord(true);
		textAreaBattleDescription.setBounds(260, 207, 361, 72);
		battleScreen.add(textAreaBattleDescription);
		
		btnFlee.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				textAreaBattleDescription.setText("Run away from the battle");
			}
		});
		btnFlee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(monster.getCurrentHealth() < (monster.getMaxHealth() / 2)) //If monster is under half health
				{
					monster.setCurrentHealth(monster.getMaxHealth() / 2); //Add some health to monster as punishment for fleeing
				}
				Timer timer = new Timer(0, loadPrepScreen);
				timer.setRepeats(false);
				timer.start();
				battleScreen.setVisible(false);
				prepScreen.setVisible(true);
			}
		});
		btnBattleUseItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Timer timer = new Timer(0, disableBattleButtons);
				timer.setRepeats(false);
				timer.start();
				
				if(hero.getItem().getItemName() == "apple")
				{
					textAreaBattleDialog.append("Yummy! You regained some health! \n");		
				}
				hero.useItem();
				lblBattleHeroHealth.setText("Health: " + hero.getCurrentHealth() + "/" + hero.getMaxHealth());
				
				
				Timer timerDelay = new Timer(2000, monsterTurn);
				timerDelay.setRepeats(false);
				timerDelay.start();
						
				Timer timer2 = new Timer(2001, enableBattleButtons);
				timer2.setRepeats(false);
				timer2.start();
				
			}
		});
		btnBattleUseItem.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				textAreaBattleDescription.setText("Use one of your items. Be wary that you lose a turn if you use one");
			}
		});
		btnBattleAttack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				textAreaBattleDescription.setText("Attack the enemy for anywhere between " + hero.getBaseAttack(-5) + " and " + hero.getBaseAttack(5) + " damage");
			}
		});
		btnBattleAttack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//Attack button pressed. Initiate attack sequence on enemy
				//Hero attack method is ran.
				//Battle notifications sent back up to dialog, indicating damage
				//All labels updated to match current scenarios, including health
				//Give time to let player see their current health and how much damage they dealt before passing turn to enemy
				//Turn is passed to the enemy
				//Enemy action is indicated in dialog
				//All labels updated to match current, including health
				
				Timer timer = new Timer(0, disableBattleButtons);
				timer.setRepeats(false);
				timer.start();
				
				int damage = hero.Attack() * monster.getDefenseDebuff();
				monster.setDefenseDebuff(1);
				if(hero.isGotCritHit())
				{
					textAreaBattleDialog.append("Critical hit! You struck the monster for " + damage + " damage! \n");
					
					if(hero.getCurrentHero() == "Wizard") //Special wizard properties
					{
						int number = rand.nextInt(300);
						if(number <= 100)
						{
							monster.setDefenseDebuff(2);
							textAreaBattleDialog.append("Defense down spell. Your next attack will deal double damage! \n");
						}
						else if(number > 100 && number <= 200)
						{
							monster.setAttackDebuff(2);
							textAreaBattleDialog.append("Attack down spell. Monster's next attack will deal half damage! \n");
							
						}
						else if(number > 200 && number <= 300)
						{
							monster.setStunned(true);
							textAreaBattleDialog.append("The monster has been stunned. You get another turn! \n");
							
						}
					}
					
					hero.setGotCritHit(false);
				}
				else 
				{
					textAreaBattleDialog.append("You hit the monster for " + damage + " damage! \n");
				}
				textAreaBattleDialog.setCaretPosition(textAreaBattleDialog.getDocument().getLength());
				monster.setCurrentHealth(monster.getCurrentHealth() - damage);
				if(monster.getCurrentHealth()<0)
				{
					monster.setCurrentHealth(0);
				}
				lblBattleMonsterHealth.setText("Health: " + monster.getCurrentHealth() + "/" + monster.getMaxHealth());
				
				//Monster's turn.
					Timer timerDelay = new Timer(1000, monsterTurn); //Delayed for 1 second
					timerDelay.setRepeats(false);
					timerDelay.start();
				
				
				
				Timer timer2 = new Timer(1001, enableBattleButtons);
				timer2.setRepeats(false);
				timer2.start();
			}
		});
		
		JLabel lblBattleBackground = new JLabel("");
		lblBattleBackground.setIcon(new ImageIcon(Game.class.getResource("background.jpg")));
		lblBattleBackground.setBounds(0, 0, 674, 403);
		battleScreen.add(lblBattleBackground);

		//Shop Screen
		
		JLabel lblShop = new JLabel("Shop");
		lblShop.setOpaque(true);
		lblShop.setHorizontalAlignment(SwingConstants.CENTER);
		lblShop.setFont(new Font("Freestyle Script", Font.PLAIN, 40));
		lblShop.setBackground(Color.GRAY);
		lblShop.setBounds(0, 0, 664, 52);
		shopScreen.add(lblShop);
		
		JLabel lblShopCurrentBalance = new JLabel("Current Balance:");
		lblShopCurrentBalance.setOpaque(true);
		lblShopCurrentBalance.setBounds(271, 223, 149, 26);
		shopScreen.add(lblShopCurrentBalance);
		
		JLabel lblShopCost = new JLabel("Cost:");
		lblShopCost.setOpaque(true);
		lblShopCost.setBounds(271, 248, 149, 26);
		shopScreen.add(lblShopCost);
		
		JLabel lblShopNewBalance = new JLabel("New Balance:");
		lblShopNewBalance.setOpaque(true);
		lblShopNewBalance.setBounds(271, 269, 149, 26);
		shopScreen.add(lblShopNewBalance);
		
		JTextArea textAreaShopItemDescription = new JTextArea();
		textAreaShopItemDescription.setEditable(false);
		textAreaShopItemDescription.setLineWrap(true);
		textAreaShopItemDescription.setWrapStyleWord(true);
		textAreaShopItemDescription.setFont(new Font("Tahoma", Font.PLAIN, 16));
		textAreaShopItemDescription.setBounds(21, 203, 227, 129);
		shopScreen.add(textAreaShopItemDescription);
		
		JTextArea textAreaShopUpgradeDescription = new JTextArea();
		textAreaShopUpgradeDescription.setBounds(505, 61, 149, 99);
		shopScreen.add(textAreaShopUpgradeDescription);
		textAreaShopUpgradeDescription.setWrapStyleWord(true);
		textAreaShopUpgradeDescription.setLineWrap(true);
		textAreaShopUpgradeDescription.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		JLabel lblShopCurrentUpgradePoints = new JLabel("Current Upgrade Points:");
		lblShopCurrentUpgradePoints.setOpaque(true);
		lblShopCurrentUpgradePoints.setBounds(505, 160, 149, 26);
		shopScreen.add(lblShopCurrentUpgradePoints);
		
		JLabel lblShopUpgradePointCost = new JLabel("Point Cost:");
		lblShopUpgradePointCost.setOpaque(true);
		lblShopUpgradePointCost.setBounds(505, 184, 149, 26);
		shopScreen.add(lblShopUpgradePointCost);
		
		JButton btnShopBuy = new JButton("Buy");
		btnShopBuy.setBounds(271, 306, 149, 26);
		shopScreen.add(btnShopBuy);
		
		JPanel panelShopAssistItems = new JPanel();
		panelShopAssistItems.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Assist Items", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panelShopAssistItems.setBounds(25, 85, 120, 52);
		shopScreen.add(panelShopAssistItems);
		panelShopAssistItems.setLayout(null);
		
		JRadioButton rdbtnShopApple = new JRadioButton("Apple");
		rdbtnShopApple.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(hero.getBalance() -50 < 0 || hero.getItem() != null)
				{
					btnShopBuy.setEnabled(false);
				}
				else
				{
					btnShopBuy.setEnabled(true);
				}
				textAreaShopItemDescription.setText("Heals 60 health during battle");
				lblShopCost.setText("Cost: 50");
				lblShopNewBalance.setText("New Balance: " + hero.getBalance(-50));
			}
		});
		buttonGroup_1.add(rdbtnShopApple);
		rdbtnShopApple.setBounds(6, 16, 109, 23);
		panelShopAssistItems.add(rdbtnShopApple);
		
		JPanel panelShopUpgrades = new JPanel();
		panelShopUpgrades.setLayout(null);
		panelShopUpgrades.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Upgrades", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panelShopUpgrades.setBounds(327, 68, 168, 116);
		shopScreen.add(panelShopUpgrades);
		
		JRadioButton rdbtnHealth = new JRadioButton("Health");
		rdbtnHealth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textAreaShopUpgradeDescription.setText("Increase health by 20");
				lblShopUpgradePointCost.setText("Point Cost: 1");
			}
		});
		buttonGroup_2.add(rdbtnHealth);	
		rdbtnHealth.setBounds(6, 16, 109, 23);
		panelShopUpgrades.add(rdbtnHealth);
		
		JRadioButton rdbtnAttack = new JRadioButton("Attack");
		rdbtnAttack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textAreaShopUpgradeDescription.setText("Increase attack by 10");
				lblShopUpgradePointCost.setText("Point Cost: 1");
			}
		});
		buttonGroup_2.add(rdbtnAttack);
		rdbtnAttack.setBounds(6, 37, 109, 23);
		panelShopUpgrades.add(rdbtnAttack);
		
		JRadioButton rdbtnSpeed = new JRadioButton("Speed");
		rdbtnSpeed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textAreaShopUpgradeDescription.setText("Increase speed by 10, meaning you are an additional 10% more likely to dodge");
				lblShopUpgradePointCost.setText("Point Cost: 1");
			}
		});
		buttonGroup_2.add(rdbtnSpeed);
		rdbtnSpeed.setBounds(6, 59, 109, 23);
		panelShopUpgrades.add(rdbtnSpeed);
		
		JRadioButton rdbtnCriticalHitChance = new JRadioButton("Critical Hit Chance");
		buttonGroup_2.add(rdbtnCriticalHitChance);
		rdbtnCriticalHitChance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textAreaShopUpgradeDescription.setText("Increase critical hit chance by 10%");
				lblShopUpgradePointCost.setText("Point Cost: 1");
			}
		});
		rdbtnCriticalHitChance.setBounds(6, 85, 127, 23);
		panelShopUpgrades.add(rdbtnCriticalHitChance);
		
		JButton btnShopUpgrade = new JButton("Upgrade");
		btnShopUpgrade.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				hero.setUpgradePoints(hero.getUpgradePoints() - 1);
				lblShopCurrentUpgradePoints.setText("Current Points: " + hero.getUpgradePoints());
				if(hero.getUpgradePoints() == 0)
				{
					btnShopUpgrade.setEnabled(false);
				}
				
				if(rdbtnHealth.isSelected())
				{
					hero.setMaxHealth(hero.getMaxHealth() + 10);
				}
				else if(rdbtnAttack.isSelected())
				{
					hero.setBaseAttack(hero.getBaseAttack() + 10);
				}
				else if(rdbtnSpeed.isSelected())
				{
					hero.setSpeed(hero.getSpeed() + 10);
				}
				else if(rdbtnCriticalHitChance.isSelected())
				{
					hero.setCritChance(hero.getCritChance() + 10);
				}
				JOptionPane.showMessageDialog(null, "Upgrade successful!");
			}
		});
		btnShopUpgrade.setBounds(505, 217, 149, 26);
		shopScreen.add(btnShopUpgrade);
		
		
		
		btnShopBuy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(rdbtnShopApple.isSelected() && hero.getBalance() -50 >= 0)
				{
					btnShopBuy.setEnabled(false);
					hero.Buy("apple");
					lblShopCurrentBalance.setText("Current Balance: " + hero.getBalance());
					lblShopNewBalance.setText("New Balance: " + hero.getBalance(-50));
					JOptionPane.showMessageDialog(null,	"Item bought successfully! You must use it before you can buy another one");
				}
				else
				{
					JOptionPane.showMessageDialog(null, "You must choose an item first");
				}
			}
		});
		
		JButton btnShopLeave = new JButton("Leave");
		btnShopLeave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Timer timer = new Timer(0, loadPrepScreen);
				timer.setRepeats(false);
				timer.start();
				shopScreen.setVisible(false);
				prepScreen.setVisible(true);
			}
		});
		btnShopLeave.setBounds(505, 306, 149, 43);
		shopScreen.add(btnShopLeave);
		
		JLabel lblShopBackground = new JLabel("");
		lblShopBackground.setIcon(new ImageIcon(Game.class.getResource("background.jpg")));
		lblShopBackground.setBounds(0, 0, 674, 403);
		shopScreen.add(lblShopBackground);
		
		//Battle Prep Screen
		
		
		
		JButton btnShop = new JButton("Shop");
		btnShop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(hero.getItem() != null)
				{
					btnShopBuy.setEnabled(false);
				}
				else
				{
					btnShopBuy.setEnabled(true);
				}
				
				if(hero.getUpgradePoints() == 0)
				{
					btnShopUpgrade.setEnabled(false);
				}
				else
				{
					btnShopUpgrade.setEnabled(true);
				}
				lblShopCurrentBalance.setText("Current Balance: " + hero.getBalance());
				lblShopCurrentUpgradePoints.setText("Current Points: " + hero.getUpgradePoints());
				prepScreen.setVisible(false);
				shopScreen.setVisible(true);
			}
		});
		btnShop.setBounds(531, 244, 89, 37);
		prepScreen.add(btnShop);
		
		JButton btnNewButton = new JButton("Fight");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lblBattleHeroHealth.setText("Health: " + hero.getCurrentHealth() + "/" + hero.getMaxHealth());
				lblBattleMonsterHealth.setText("Health: " + monster.getCurrentHealth() + "/" + monster.getMaxHealth());
				textAreaBattleDialog.setText("");
				if(hero.getItem() == null)
				{
					btnBattleUseItem.setEnabled(false);
				}
				else
				{
					btnBattleUseItem.setEnabled(true);
				}
				battleRound = 1;
				prepScreen.setVisible(false);
				battleScreen.setVisible(true);
			}
		});
		btnNewButton.setBounds(531, 294, 89, 63);
		prepScreen.add(btnNewButton);
		
		JButton btnQuit = new JButton("Quit");
		btnQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				level = 1;
				prepScreen.setVisible(false);
				titleScreen.setVisible(true);
			}
		});
		btnQuit.setBounds(360, 364, 89, 32);
		prepScreen.add(btnQuit);
		
		JLabel lblPrepBackground = new JLabel("");
		lblPrepBackground.setIcon(new ImageIcon(Game.class.getResource("background.jpg")));
		lblPrepBackground.setOpaque(true);
		lblPrepBackground.setBounds(0, 0, 664, 403);
		prepScreen.add(lblPrepBackground);
		
		
		//Title Screen
		
		JButton btnStart = new JButton("Start");
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				titleScreen.setVisible(false);
				selectScreen.setVisible(true);
			}
		});
		btnStart.setBounds(128, 256, 131, 61);
		titleScreen.add(btnStart);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnExit.setBounds(416, 256, 123, 61);
		titleScreen.add(btnExit);
		
		JLabel lblLogo = new JLabel("Medieval Quest");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setFont(new Font("Freestyle Script", Font.PLAIN, 54));
		lblLogo.setBounds(148, 62, 398, 123);
		titleScreen.add(lblLogo);
		
		JLabel lblScroll = new JLabel("New label");
		lblScroll.setIcon(new ImageIcon(Game.class.getResource("logo.png")));
		lblScroll.setBounds(128, 31, 418, 186);
		titleScreen.add(lblScroll);
		
		JLabel lblBackground = new JLabel("");
		lblBackground.setIcon(new ImageIcon(Game.class.getResource("background.jpg")));
		lblBackground.setBounds(0, 0, 664, 403);
		titleScreen.add(lblBackground);
	}
}