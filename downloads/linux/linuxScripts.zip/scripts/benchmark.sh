#!/bin/bash
sysbench --test=cpu --cpu-max-prime=20000 run > /home/rrennehan/data/benchmarks/cpuBenchmark_`date +"%Y_%m_%d_%T"`.txt
