#!/bin/bash
systemctl status mysql > /home/rrennehan/data/dbmsStatus/mysqlStatus_`date +"%Y_%m_%d_%T"`.txt
