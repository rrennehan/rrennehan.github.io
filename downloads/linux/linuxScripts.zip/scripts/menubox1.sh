#!/bin/bash
# utilitymenu.sh - A sample shell script to display menus on screen
# Store menu options selected by the user
INPUT=/tmp/menu.sh.$$

# Storage file for displaying cal and date command output
OUTPUT=/tmp/output.sh.$$

# get text editor or fall back to vi_editor
vi_editor=${EDITOR-vi}

# trap and delete temp files
trap "rm $OUTPUT; rm $INPUT; exit" SIGHUP SIGINT SIGTERM

#
# Purpose - display output using msgbox 
#  $1 -> set msgbox height
#  $2 -> set msgbox width
#  $3 -> set msgbox title
#

function display_output(){
	local h=${1-10}			# box height default 10
	local w=${2-41} 		# box width default 41
	local t=${3-Output} 	# box title 
	dialog --backtitle "Linux Shell Script Tutorial" --title "${t}" --clear --msgbox "$(<$OUTPUT)" ${h} ${w}
}

#
# Purpose - display current system date & time
#

function show_date(){
	echo "Today is $(date) @ $(hostname -f)." >$OUTPUT
    display_output 6 60 "Date and Time"
}

#
# Purpose - display a calendar
#

function show_calendar(){
	cal >$OUTPUT
	display_output 13 25 "Calendar"
}

#
# Purporse - Show location
#
function show_location(){ #New function
	echo "You are at $(pwd)" >$OUTPUT
	display_output 6 60 "Location"
}

#
# Show directory details
#
function show_details(){ #New function
	dialog --inputbox "Enter Directory:" 8 40 2>$OUTPUT
	theDirectory=$(<$OUTPUT)
	if [ -d "$theDirectory" ] && [ "$theDirectory" != "/" ] && [[ $theDirectory != /* ]]; then
		echo "Permissions: $(ls -ld $theDirectory) \n Number of files and folders: $(ls $theDirectory | wc -l) \n Size and name of largest file: $(find $theDirectory -type f -printf "%s\t%p\n" | sort -n | tail -1)" >$OUTPUT
	else
		echo "The directory does not exist or is not compatible" >$OUTPUT
	fi
	display_output 12 90 "Directory Details"
}
#
# set infinite loop
#

while true
do
### display main menu ###
dialog --clear --backtitle "Linux Shell Script Tutorial" \
--title "[ M A I N - M E N U ]" \
--menu "You can use the UP/DOWN arrow keys, the first \n\
letter of the choice as a hot key, or the \n\
number keys 1-9 to choose an option.\n\
Choose the TASK" 15 50 4 \
Date/time "Displays date and time" \
Calendar "Displays a calendar" \
Where\ am\ I? "Displays location" \
Directory\ Details "Displays permissions" \
Editor "Start a text editor" \
Exit "Exit to the shell" 2>"${INPUT}"
menuitem=$(<"${INPUT}")

# make decision 

case $menuitem in
	Date/time) show_date;;
	Calendar) show_calendar;;
	Where\ am\ I?) show_location;;
	Directory\ Details) show_details;;
	Editor) $vi_editor;;
	Exit) echo "Bye"; break;;
esac
done

# if temp files found, delete em
[ -f $OUTPUT ] && rm $OUTPUT
[ -f $INPUT ] && rm $INPUT
