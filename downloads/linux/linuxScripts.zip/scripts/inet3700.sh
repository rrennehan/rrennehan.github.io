#!/bin/bash
# utilitymenu.sh - A sample shell script to display menus on screen
# Store menu options selected by the user

if [ $(id -u) -eq 0 ]; then
	echo "Run this script without sudo"
	exit
fi

runUser=$USER

echo "This menu box contains commands that can alter your system"
sudo echo ""

INPUT=/tmp/menu.sh.$$

# Storage file for displaying cal and date command output
OUTPUT=/tmp/output.sh.$$

# get text editor or fall back to vi_editor
vi_editor=${EDITOR-vi}

# trap and delete temp files
trap "rm $OUTPUT; rm $INPUT; exit" SIGHUP SIGINT SIGTERM

#
# Purpose - display output using msgbox 
#  $1 -> set msgbox height
#  $2 -> set msgbox width
#  $3 -> set msgbox title
#

function display_output(){
	local h=${1-10}			# box height default 10
	local w=${2-41} 		# box width default 41
	local t=${3-Output} 	# box title 
	dialog --backtitle "Linux Shell Script Tutorial" --title "${t}" --clear --msgbox "$(<$OUTPUT)" ${h} ${w}
}

#
# Purpose - Add users specified from CSV file
#
function csvAddUsers(){
	if [ -f NewUsers.csv ]; then
		while IFS="," read username password; do
			sudo useradd $username
			echo "$username:$password" | sudo chpasswd
			echo "added $username"
		done < NewUsers.csv
		echo "Users added successfully!" >$OUTPUT
	else
		echo "Ensure a file called NewUsers.csv exists in the same folder as the script. Format is username,password" >$OUTPUT
	fi
	display_output 12 90 "Add Users"
}

#
# Purpose - Delete users specified from CSV file
#
function csvDelUsers(){
	if [ -f NewUsers.csv ]; then
		while IFS="," read username password; do
			sudo deluser $username
		done < NewUsers.csv
		echo "Users deleted successfully" >$OUTPUT
	else
		echo "Ensure a file called NewUsers.csv exists in the same folder as the script. Format is username,password" >$OUTPUT
	fi
	display_output 12 90 "Delete Users"
}

#
# Purpose - Back up all databases for any mySQL user
#

function sqlBackup(){
	dialog --inputbox "Enter mySQL username (e.g. root):" 8 40 2>$OUTPUT 
	theName=$(<$OUTPUT)
	dialog --passwordbox "Enter mySQL password:" 8 40 2>$OUTPUT
	thePassword=$(<$OUTPUT)
	mysql --user="${theName}" --password="${thePassword}" -e exit 2>/dev/null
	userExists=`echo $?`
	if [ $userExists -eq 0 ]; then
		printf "[mysqldump]\nuser=$theName\npassword=$thePassword\n" > $HOME/.my.cnf
		mkdir -p $HOME/data/SQLBackUp
		sudo chown -R $runUser $HOME/data/SQLBackUp
		mysqldump -u $theName --all-databases | gzip > $HOME/data/SQLBackUp/mysqldb_`date +"%Y_%m_%d_%T"`.sql.gz
		echo "Backup created successfully! Check out $HOME/data/SQLBackUp." >$OUTPUT
	else
		echo "The user and password you specified does not exist" >$OUTPUT
	fi
	display_output 12 90 "Backup SQL Database"
}

#
# Purpose - Perform a CPU benchmark
#

function benchmark(){
	sudo dpkg -s sysbench &> /dev/null
	installed=`echo $?`
	if [ $installed -ne 0 ]; then
		dialog --yesno "The sysbench tool is not installed. Would you like to install it?" 8 40 2>$OUTPUT
		response=$?
		if [ $response -eq 0 ]; then
			sudo apt install sysbench
		else
			return
		fi
	fi
	mkdir -p $HOME/data/benchmarks
	sudo chown -R $runUser $HOME/data/benchmarks
	benchmarkResults="$(sysbench --test=cpu --cpu-max-prime=20000 run)"
	echo "$benchmarkResults" > $HOME/data/benchmarks/cpuBenchmark_`date +"%Y_%m_%d_%T"`.txt
	echo "$benchmarkResults" >$OUTPUT
	display_output 75 90 "Benchmark Tool"
}

#
# Purpose - Update system packages
#
function update(){
	sudo apt update
	sudo apt upgrade
	if [ $? -eq 0 ]; then
		echo "Packages successfully upgraded" >$OUTPUT
	else
		echo "An error occured while upgrading" >$OUTPUT
	fi
	display_output 12 90 "Update and Upgrade"
}
#
# set infinite loop
#

while true
do
### display main menu ###
dialog --clear --backtitle "Linux Shell Script Tutorial" \
--title "[ M A I N - M E N U ]" \
--menu "You can use the UP/DOWN arrow keys, the first \n\
letter of the choice as a hot key, or the \n\
number keys 1-9 to choose an option.\n\
Choose the TASK" 15 75 4 \
Add\ Users\ from\ CSV "Adds users from NewUsers.csv" \
Del\ Users\ from\ CSV "Deletes users specified in NewUsers.csv" \
mySQL\ Backup "Backups user's database" \
CPU\ Benchmark "CPU test at 20000 max events" \
Update\ Packages "Runs update and upgrade" \
Exit "Exit to the shell" 2>"${INPUT}"
menuitem=$(<"${INPUT}")

# make decision 

case $menuitem in
	Add\ Users\ from\ CSV) csvAddUsers;;
	Del\ Users\ from\ CSV) csvDelUsers;;
	mySQL\ Backup) sqlBackup;;
	CPU\ Benchmark) benchmark;;
	Update\ Packages) update;;
	Exit) echo "Bye"; break;;
esac
done

# if temp files found, delete em
[ -f $OUTPUT ] && rm $OUTPUT
[ -f $INPUT ] && rm $INPUT
