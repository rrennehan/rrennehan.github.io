#!/bin/bash

printf "[mysqldump]\nuser=root\npassword=1tsas5cr5t\n" > /home/rrennehan/.my.cnf
mysqldump -u root --all-databases | gzip > /home/rrennehan/data/SQLBackUp/mysqldb_`date +"%Y_%m_%d_%T"`.sql.gz
