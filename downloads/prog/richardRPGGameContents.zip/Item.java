//
public class Item {

	String itemName;
	int healthGiven;
	
	public Item(String itemName, int healthGiven) {
		super();
		this.itemName = itemName;
		this.healthGiven = healthGiven;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getHealthGiven() {
		return healthGiven;
	}

	public void setHealthGiven(int healthGiven) {
		this.healthGiven = healthGiven;
	}
	
	
}
