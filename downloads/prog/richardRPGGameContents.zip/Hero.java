//
import java.util.ArrayList;
import java.util.Random;

public class Hero extends Character
{
	private String[] heroNames = {"Knight", "Archer", "Wizard"};
	private String currentHero;
	private Item item; //Aggregation example
	private int lives = 3;
	private int balance = 100;
	private int upgradePoints = 0;
	private int speed; 
	private int critChance;
	private boolean gotCritHit = false;
	
	public String[] getHeroNames() {
		return heroNames;
	}

	public void setHeroNames(String[] heroNames) {
		this.heroNames = heroNames;
	}

	
	
	
	
	
	public Hero(int level, int currentHealth, int maxHealth, int baseAttack, String currentHero, int speed,
			int critChance) {
		super(level, currentHealth, maxHealth, baseAttack);
		this.currentHero = currentHero;
		this.speed = speed;
		this.critChance = critChance;
	}

	
	
	
	//Hero Methods
	
	
	public String getCurrentHero() {
		return currentHero;
	}




	public boolean isGotCritHit() {
		return gotCritHit;
	}




	public void setGotCritHit(boolean gotCritHit) {
		this.gotCritHit = gotCritHit;
	}




	public void setCurrentHero(String currentHero) {
		this.currentHero = currentHero;
	}


	public int getLives() {
		return lives;
	}




	public void setLives(int lives) {
		this.lives = lives;
	}




	public int getBalance() {
		return balance;
	}
	
	public int getBalance(int value) {
		return balance + value;
	}




	public void setBalance(int balance) {
		this.balance = balance;
	}




	public int getUpgradePoints() {
		return upgradePoints;
	}




	public void setUpgradePoints(int upgradePoints) {
		this.upgradePoints = upgradePoints;
	}




	public int getSpeed() {
		return speed;
	}




	public void setSpeed(int speed) {
		this.speed = speed;
	}




	public int getCritChance() {
		return critChance;
	}




	public void setCritChance(int critChance) {
		this.critChance = critChance;
	}


	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}




	@Override
	public int Attack() {
		Random rand = new Random();
		int damage = rand.nextInt((super.getBaseAttack() + 5) - (super.getBaseAttack() - 5) + 1) + (super.getBaseAttack() - 5);
		int number = rand.nextInt(100);
		if(number <= critChance)
		{
			damage *= 2;
			gotCritHit = true;
		}
		return damage;
		//Move to enemy's turn
	}
	@Override
	public void Defend() {
		
		//Move to enemy's attack overloaded for when user is defending
		//40% chance of user dodging next attack and striking back
		//If not, user takes half the damage.
	}
	
	@Override
	public void Defeated() {
		//Lose a life
		//Go back one level in the game
	}
	
	public void LevelUp() {
		setLevel(super.getLevel() + 1);
		upgradePoints += 1;
	}
	
	public void Upgrade() {
		//Check to see if sufficient upgrade points
		//Upgrade chosen attribute
		//Reduce upgrade points
	}
	
	public void Buy(String value) {
		if(value == "apple")
		{
			balance -= 50;
			item = new Item("apple", 60);
		}
		else if(value == "defense potion")
		{
			
		}
	}
	
	public void useItem() {
		if(item.getItemName() == "apple")
		{
			super.setCurrentHealth(super.getCurrentHealth() + 60);
			if(super.getCurrentHealth() > super.getMaxHealth())
			{
				super.setCurrentHealth(super.getMaxHealth());
			}
		}
		
		item = null;
		
		//update game labels
		//Disable button in game
	}
}