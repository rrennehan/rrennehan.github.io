//
public abstract class Character extends Game {
	
	private int level;
	private int currentHealth;
	private int maxHealth;
	private int baseAttack;
	

	public Character(int level, int currentHealth, int maxHealth, int baseAttack) {
		this.level = level;
		this.currentHealth = currentHealth;
		this.maxHealth = maxHealth;
		this.baseAttack = baseAttack;
	}
	
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getCurrentHealth() {
		return currentHealth;
	}
	public void setCurrentHealth(int d) {
		this.currentHealth = d;
	}

	public int getMaxHealth() {
		return maxHealth;
	}
	public void setMaxHealth(int maxHealth) {
		this.maxHealth = maxHealth;
	}
	public int getBaseAttack() {
		return baseAttack;
	}
	
	public int getBaseAttack(int value) {
		return baseAttack + value;
	}
	
	public void setBaseAttack(int baseAttack) {
		this.baseAttack = baseAttack;
	}
	public abstract int Attack();
	public abstract void Defend();
	public abstract void Defeated();
}
