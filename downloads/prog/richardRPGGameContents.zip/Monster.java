//
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

public class Monster extends Character {

	private String[] monsterTypes = {"Giant Spider", "Werewolf", "Demon Bear"};
	private String currentMonster;
	private int goldDrop;
	private boolean heroIsDefending = false;
	private boolean isStunned = false; //the wizard can stun the enemy at random. Stun means a turn is lost
	private int attackDebuff = 1;
	private int defenseDebuff = 1;


	public boolean isDefeated() {
		return isDefeated;
	}

	public void setDefeated(boolean isDefeated) {
		this.isDefeated = isDefeated;
	}

	private boolean isDefeated = false;

	public Monster(int level, int currentHealth, int maxHealth, int baseAttack, String currentMonster, int goldDrop) {
		super(level, currentHealth, maxHealth, baseAttack);
		this.currentMonster = currentMonster;
		this.goldDrop = goldDrop;
	}

	public String[] getMonsterTypes() {
		return monsterTypes;
	}

	public void setMonsterTypes(String[] monsterTypes) {
		this.monsterTypes = monsterTypes;
	}

	public String getCurrentMonster() {
		return currentMonster;
	}

	public void setCurrentMonster(String currentMonster) {
		this.currentMonster = currentMonster;
	}

	public int getGoldDrop() {
		return goldDrop;
	}

	public void setGoldDrop(int goldDrop) {
		this.goldDrop = goldDrop;
	}

	public boolean isHeroIsDefending() {
		return heroIsDefending;
	}

	public void setHeroIsDefending(boolean heroIsDefending) {
		this.heroIsDefending = heroIsDefending;
	}

	public boolean isStunned() {
		return isStunned;
	}

	public void setStunned(boolean isStunned) {
		this.isStunned = isStunned;
	}

	public int getAttackDebuff() {
		return attackDebuff;
	}

	public void setAttackDebuff(int attackDebuff) {
		this.attackDebuff = attackDebuff;
	}

	public int getDefenseDebuff() {
		return defenseDebuff;
	}

	public void setDefenseDebuff(int defenseDebuff) {
		this.defenseDebuff = defenseDebuff;
	}

	//Monster Methods
	
	@Override
	public int Attack() {
		Random rand = new Random();
		int damage = rand.nextInt((super.getBaseAttack() + 5) - (super.getBaseAttack() - 5) + 1) + (super.getBaseAttack() - 5);
		double damageReduction = Math.ceil(damage / attackDebuff);
		if(damageReduction != damage) 
		{
			damage -= damageReduction;
		}
		return damage;
	}
	
	@Override
	public void Defend() { //Not implemented yet due to time constraints
		
	}
	
	@Override
	public void Defeated() {
		isDefeated = true;
	}
}