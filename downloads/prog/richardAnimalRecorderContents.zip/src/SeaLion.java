
public class SeaLion extends Animal {

	private int numOfSpots;

	public SeaLion() {
		
	}

	public int getNumOfSpots() {
		return numOfSpots;
	}

	public void setNumOfSpots(int numOfSpots) {
		this.numOfSpots = numOfSpots;
	}
}