
public class Penguin extends Animal {

	private double bloodPressure;

	public Penguin() {

	}

	public double getBloodPressure() {
		return bloodPressure;
	}

	public void setBloodPressure(double bloodPressure) {
		this.bloodPressure = bloodPressure;
	}
}