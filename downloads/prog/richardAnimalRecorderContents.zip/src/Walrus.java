
public class Walrus extends Animal {

	private final String[] dentalHealthLevels = {"good", "average", "poor"};
	private String dentalHealth;
	
	public Walrus() {

	}

	public String getDentalHealth() {
		return dentalHealth;
	}

	public void setDentalHealth(int index) {
		this.dentalHealth = dentalHealthLevels[index];
	}
}