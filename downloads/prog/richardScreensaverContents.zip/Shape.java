import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public abstract class Shape {

	private Color color;
	private int width;
	private int height;
	private int xPosition;
	private int yPosition;
	private int xSpeed; //how much the shape goes up the x-axis each time
	private int ySpeed; //how much the shape goes up the y-axis each time
	private Rectangle boundary; //Used for collection detection

	public Shape(Color color, int width, int height, int xPosition, int yPosition, int xSpeed, int ySpeed) {
		super();
		this.color = color;
		this.width = width;
		this.height = height;
		this.xPosition = xPosition;
		this.yPosition = yPosition;
		this.xSpeed = xSpeed;
		this.ySpeed = ySpeed;
	}
	
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getxPosition() {
		return xPosition;
	}
	public void setxPosition(int xPosition) {
		this.xPosition = xPosition;
	}
	public int getyPosition() {
		return yPosition;
	}
	public void setyPosition(int yPosition) {
		this.yPosition = yPosition;
	}
	public int getxSpeed() {
		return xSpeed;
	}
	public void setxSpeed(int xSpeed) {
		this.xSpeed = xSpeed;
	}
	public int getySpeed() {
		return ySpeed;
	}
	public void setySpeed(int ySpeed) {
		this.ySpeed = ySpeed;
	}

	public Rectangle getBoundary() {
		return boundary;
	}

	public void setBoundary(Rectangle boundary) {
		this.boundary = boundary;
	}

	public abstract void drawShape(Graphics g); //All shapes have unique drawShape method.
	
	
	public void moveShape(DrawingPanel dp, Graphics g) { //All shapes move the same way
		
		//Update coordinates
		this.setxPosition(this.getxPosition() + this.getxSpeed());
		this.setyPosition(this.getyPosition() + this.getySpeed());
		
		//Check for collision with walls
		if(this.getxPosition()+this.getWidth() >= dp.getWidth() || this.getxPosition() <= 0) {
			this.setxSpeed(this.getxSpeed() * -1);
		}
		if(this.getyPosition()+this.getHeight() >= dp.getHeight() || this.getyPosition() <= 0) {
			this.setySpeed(this.getySpeed() * -1);
		}
		
		//Check for collision with other shapes
		
		Rectangle r1 = this.getBoundary().getBounds();
		for(int i = 0; i < DrawingPanel.shapes.size(); i++)
		{
			if(DrawingPanel.shapes.get(i) == this)
				continue; //Ignore if it is the same shape as this shape
			Rectangle r2 = DrawingPanel.shapes.get(i).getBoundary().getBounds();
			if(r1.intersects(r2))
			{
				if(r1.x + r1.width <= r2.x + 6) //Right side of first rectangle hits left side of second rectangle
				{
					this.setxPosition(r2.x - r1.width - 1);
					this.setBoundary(new Rectangle(this.getxPosition(), this.getyPosition(), this.getWidth(), this.getHeight()));
					r1.setBounds(this.getBoundary());
					this.setxSpeed(this.getySpeed() * -1);
					DrawingPanel.shapes.get(i).setxSpeed(DrawingPanel.shapes.get(i).getxSpeed() * -1);
				}
				
				else if(r1.x >= r2.x + r2.width - 6) //Left side of first rectangle hits right side of second rectangle
				{
					this.setxPosition(r2.x + r2.width + 1);
					this.setBoundary(new Rectangle(this.getxPosition(), this.getyPosition(), this.getWidth(), this.getHeight()));
					r1.setBounds(this.getBoundary());
					this.setxSpeed(this.getxSpeed() * -1);
					DrawingPanel.shapes.get(i).setxSpeed(DrawingPanel.shapes.get(i).getxSpeed() * -1);
				}
				else if(r1.y >= r2.y - 6) //Top of first rectangle hits bottom of second rectangle
				{
					this.setyPosition(r2.y + r2.height + 1);
					this.setBoundary(new Rectangle(this.getxPosition(), this.getyPosition(), this.getWidth(), this.getHeight()));
					r1.setBounds(this.getBoundary());
					if((this.getySpeed() < 0 && DrawingPanel.shapes.get(i).getySpeed() < 0) ||
							this.getySpeed() > 0 && DrawingPanel.shapes.get(i).getySpeed() > 0)
					{
						DrawingPanel.shapes.get(i).setySpeed(DrawingPanel.shapes.get(i).getySpeed() * -1);
						continue;
					}
					this.setySpeed(this.getySpeed() * -1);
					DrawingPanel.shapes.get(i).setySpeed(DrawingPanel.shapes.get(i).getySpeed() * -1);
				}
				
				else if(r1.y + r1.height <= r2.y + 6) //Bottom of first rectangle hits top of second rectangle
				{
					this.setyPosition(r2.y - r1.height -1);
					this.setBoundary(new Rectangle(this.getxPosition(), this.getyPosition(), this.getWidth(), this.getHeight()));
					r1.setBounds(this.getBoundary());
					if((this.getySpeed() < 0 && DrawingPanel.shapes.get(i).getySpeed() < 0) ||
							this.getySpeed() > 0 && DrawingPanel.shapes.get(i).getySpeed() > 0)
					{
						this.setySpeed(this.getySpeed() * -1);
						continue;
					}
					this.setySpeed(this.getySpeed() * -1);
					DrawingPanel.shapes.get(i).setySpeed(DrawingPanel.shapes.get(i).getySpeed() * -1);
				}
				
				
			}	
		}
	}
}


