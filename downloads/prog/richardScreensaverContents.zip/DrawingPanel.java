import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class DrawingPanel extends JPanel {
	
	Graphics g;
	private Timer timer = new Timer((int) 16.6666666667, new TimerAction()); //60 frames per second
	static ArrayList<Shape> shapes = new ArrayList<Shape>(){{add(new Square(Color.GREEN, 50, 50, 0, 0, 2, 2));}};
	
	
	/*{new Square(Color.GREEN, 50, 50, this.getWidth()/2, this.getHeight()/2, 2, 2),
			new Triangle(Color.BLUE, 50, 50, 0, 0, 2, 1),
			new Circle(Color.ORANGE, 50, 50, 50, 50, 2, 3),
			new Hourglass(Color.BLUE, 50, 50, 50, 50, 1, 3)};*/
		//Click on screen to add new shape
	
	@Override
	public void paintComponent(Graphics g2)
	{
		g = g2; //So graphics can be used in all methods
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, this.getWidth(), this.getHeight()); //Fill background
		
		for(int x = 0; x < shapes.size(); x++)
			shapes.get(x).drawShape(g);
		
		timer.start();
	}
	
	public void moveObjects() {
		for(int x = 0; x < shapes.size(); x++)
			shapes.get(x).moveShape(this, g);
		DrawingPanel.this.repaint();
	}
	
	public void addObject(MouseAdapter mouseAdapter) {
	 //Stop the timer to ensure no null pointer exceptions
		Color[] colors = {Color.GREEN, Color.BLUE, Color.ORANGE, Color.WHITE};
		int[] widths = {25,50,75,100};
		int[] heights = {25,50,75,100};
		Random rand = new Random();
		int rand1 = rand.nextInt(4); //Determines shape selected
		int rand2 = rand.nextInt(4); //Determines color selected
		int rand3 = rand.nextInt(4); //Determines width selected
		int rand4 = rand.nextInt(4); //Determines height selected
		int rand5 = rand.nextInt(3) + 1; //Determines xSpeed
		int rand6 = rand.nextInt(3) + 1; //Determines ySpeed
		switch (rand1) {
			case 0: shapes.add(new Square(colors[rand2], widths[rand3], heights[rand4], 0, 0, rand5, rand6));
			break;
			case 1: shapes.add(new Circle(colors[rand2], widths[rand3], heights[rand4], 0, 0, rand5, rand6));
			break;
			case 2: shapes.add(new Triangle(colors[rand2], widths[rand3], heights[rand4], 0, 0, rand5, rand6));
			break;
			case 3: shapes.add(new Hourglass(colors[rand2], widths[rand3], heights[rand4], 0, 0, rand5, rand6));
			break;
		}
		paintComponent(g);
	}
	
	private class TimerAction implements ActionListener {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			moveObjects();
		}	
	}
}
