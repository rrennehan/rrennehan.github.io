import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Circle extends Shape {

	public Circle(Color color, int width, int height, int xPosition, int yPosition, int xSpeed, int ySpeed) {
		super(color, width, height, xPosition, yPosition, xSpeed, ySpeed);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void drawShape(Graphics g) {
		g.setColor(this.getColor());
		g.fillOval(this.getxPosition(), this.getyPosition(), this.getWidth(), this.getHeight());
		this.setBoundary(new Rectangle(this.getxPosition(), this.getyPosition(), this.getWidth(), this.getHeight()));
	}

}
