import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.geom.GeneralPath;

public class Triangle extends Shape {
	
	int[] xCoords;
	int[] yCoords;

	public Triangle(Color color, int width, int height, int xPosition, int yPosition, int xSpeed, int ySpeed) {
		super(color, width, height, xPosition, yPosition, xSpeed, ySpeed);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void drawShape(Graphics g) {
		Graphics2D g2d = (Graphics2D)g;
		g.setColor(this.getColor());
		xCoords = new int[]{this.getxPosition(), this.getxPosition() + this.getWidth(), this.getxPosition() + this.getWidth()/2};
		yCoords=  new int[]{this.getyPosition(), this.getyPosition(), this.getyPosition() + this.getHeight()};
		
		g2d.fillPolygon(xCoords, yCoords, 3);
		this.setBoundary(new Rectangle(this.getxPosition(), this.getyPosition(), this.getWidth(), this.getHeight()));
		
	}

	

}
