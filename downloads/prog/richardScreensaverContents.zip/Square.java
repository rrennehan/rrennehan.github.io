import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;

import javax.swing.JOptionPane;

public class Square extends Shape {

	public Square(Color color, int width, int height, int xPosition, int yPosition, int xSpeed, int ySpeed) {
		super(color, width, height, xPosition, yPosition, xSpeed, ySpeed);
	}

	@Override
	public void drawShape(Graphics g) {
		g.setColor(this.getColor());
		g.fillRect(this.getxPosition(), this.getyPosition(), this.getWidth(), this.getHeight());
		this.setBoundary(new Rectangle(this.getxPosition(), this.getyPosition(), this.getWidth(), this.getHeight()));
	}
}

