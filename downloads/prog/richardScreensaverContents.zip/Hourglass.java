import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.GeneralPath;

public class Hourglass extends Shape {
	
	int[] xCoords;
	int[] yCoords;

	public Hourglass(Color color, int width, int height, int xPosition, int yPosition, int xSpeed, int ySpeed) {
		super(color, width, height, xPosition, yPosition, xSpeed, ySpeed);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void drawShape(Graphics g) {
		Graphics2D g2d = (Graphics2D)g;
		g.setColor(this.getColor());
		
		xCoords = new int[]{this.getxPosition(), this.getxPosition() + this.getWidth(), this.getxPosition(), this.getxPosition() + this.getWidth()};
		yCoords = new int[]{this.getyPosition(), this.getyPosition() + this.getHeight(), this.getyPosition() + this.getHeight(), this.getyPosition()};
		
		GeneralPath pen = new GeneralPath();
		
		pen.moveTo(xCoords[0], yCoords[0]);
		
		for(int x = 1; x < xCoords.length; x++)
		{
			pen.lineTo(xCoords[x], yCoords[x]);
		}
		
		pen.closePath();
		
		g2d.fill(pen);
		this.setBoundary(new Rectangle(this.getxPosition(), this.getyPosition(), this.getWidth(), this.getHeight()));

	}

	

}
