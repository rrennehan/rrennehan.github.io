import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class A4Main extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldWeight;
	private JTextField textFieldBloodPressure;
	private JTextField textFieldGpsCoordinates;
	private JTextField textFieldNumOfSpots;
	private Animal penguin;
	private Animal walrus;
	private Animal sealion;
	private Animal[] animals = {penguin, walrus, sealion};
	private Animal animal; //We'll be using only one animal at a time, dynamically changing its class
	private Animal currentAnimal;
	static File inputFile;
	static Scanner fileInput;
	static FileWriter fw;
	
	
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) throws Exception {
		inputFile = new File("animalRecords.txt");
		inputFile.createNewFile();
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					A4Main frame = new A4Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}	
			}
		});
		
	}

	/**
	 * Create the frame.
	 */
	public A4Main() {
		setTitle("Animal Recorder");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 499, 332);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox comboBoxAnimal = new JComboBox();
		comboBoxAnimal.setModel(new DefaultComboBoxModel(new String[] {"Penguin", "Walrus", "Sea Lion"}));
		comboBoxAnimal.setBounds(122, 61, 86, 20);
		comboBoxAnimal.setSelectedIndex(-1);
		contentPane.add(comboBoxAnimal);
		
		JLabel lblChooseAnimal = new JLabel("Choose Animal:");
		lblChooseAnimal.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblChooseAnimal.setHorizontalAlignment(SwingConstants.RIGHT);
		lblChooseAnimal.setBounds(10, 64, 102, 14);
		contentPane.add(lblChooseAnimal);
		
		textFieldNumOfSpots = new JTextField();
		textFieldNumOfSpots.setVisible(false);
		
		JLabel lblBloodPressure = new JLabel("Blood Pressure:");
		lblBloodPressure.setVisible(false);
		lblBloodPressure.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblBloodPressure.setHorizontalAlignment(SwingConstants.RIGHT);
		lblBloodPressure.setBounds(24, 198, 88, 14);
		contentPane.add(lblBloodPressure);
		
		textFieldBloodPressure = new JTextField();
		textFieldBloodPressure.setVisible(false);
		textFieldBloodPressure.setBounds(122, 195, 86, 20);
		contentPane.add(textFieldBloodPressure);
		textFieldBloodPressure.setColumns(10);
		
		JLabel lblNumOfSpots = new JLabel("Number of Spots:");
		lblNumOfSpots.setVisible(false);
		lblNumOfSpots.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNumOfSpots.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNumOfSpots.setBounds(10, 198, 102, 14);
		contentPane.add(lblNumOfSpots);
		textFieldNumOfSpots.setColumns(10);
		textFieldNumOfSpots.setBounds(122, 195, 86, 20);
		contentPane.add(textFieldNumOfSpots);
		
		JLabel lblDentalHealth = new JLabel("Dental Health:");
		lblDentalHealth.setVisible(false);
		lblDentalHealth.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDentalHealth.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblDentalHealth.setBounds(10, 198, 102, 14);
		contentPane.add(lblDentalHealth);
		
		JComboBox comboBoxDentalHealth = new JComboBox();
		comboBoxDentalHealth.setModel(new DefaultComboBoxModel(new String[] {"Good", "Average", "Poor"}));
		comboBoxDentalHealth.setVisible(false);
		comboBoxDentalHealth.setBounds(122, 194, 86, 22);
		comboBoxDentalHealth.setSelectedIndex(-1);
		contentPane.add(comboBoxDentalHealth);
		
		JPanel panelUniversalOptions = new JPanel();
		panelUniversalOptions.setVisible(false);
		panelUniversalOptions.setBounds(10, 17, 463, 250);
		contentPane.add(panelUniversalOptions);
		panelUniversalOptions.setLayout(null);
		
		textFieldWeight = new JTextField();
		textFieldWeight.setBounds(112, 137, 86, 20);
		panelUniversalOptions.add(textFieldWeight);
		textFieldWeight.setColumns(10);
		
		JTextArea textAreaGpsCoordinates = new JTextArea();
		textAreaGpsCoordinates.setBounds(233, 25, 208, 139);
		panelUniversalOptions.add(textAreaGpsCoordinates);
		textAreaGpsCoordinates.setEditable(false);
		textAreaGpsCoordinates.setLineWrap(true);
		textAreaGpsCoordinates.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JButton btnSaveEntry = new JButton("Save Entry");
		btnSaveEntry.setBounds(10, 227, 131, 23);
		panelUniversalOptions.add(btnSaveEntry);
		
		JButton btnGenerate = new JButton("Generate Report");
		btnGenerate.setBounds(151, 227, 131, 23);
		panelUniversalOptions.add(btnGenerate);
		
		JComboBox comboBoxSex = new JComboBox();
		comboBoxSex.setBounds(112, 93, 86, 20);
		panelUniversalOptions.add(comboBoxSex);
		comboBoxSex.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
		comboBoxSex.setSelectedIndex(-1);
		
		JLabel lblSex = new JLabel("Sex:");
		lblSex.setBounds(0, 96, 102, 14);
		panelUniversalOptions.add(lblSex);
		lblSex.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblSex.setHorizontalAlignment(SwingConstants.RIGHT);
		
		JLabel lblWeightInPounds = new JLabel("Weight in Pounds:");
		lblWeightInPounds.setBounds(0, 140, 102, 14);
		panelUniversalOptions.add(lblWeightInPounds);
		lblWeightInPounds.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblWeightInPounds.setHorizontalAlignment(SwingConstants.RIGHT);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.setBounds(374, 178, 89, 23);
		panelUniversalOptions.add(btnAdd);
		
		JLabel lblGpsCoordinates = new JLabel("GPS Coordinates");
		lblGpsCoordinates.setBounds(233, 0, 208, 14);
		panelUniversalOptions.add(lblGpsCoordinates);
		lblGpsCoordinates.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblGpsCoordinates.setHorizontalAlignment(SwingConstants.CENTER);
		
		textFieldGpsCoordinates = new JTextField();
		textFieldGpsCoordinates.setBounds(233, 179, 131, 20);
		panelUniversalOptions.add(textFieldGpsCoordinates);
		textFieldGpsCoordinates.setColumns(10);
		
		JButton btnClearReport = new JButton("Clear Report");
		btnClearReport.setForeground(Color.BLACK);
		btnClearReport.setBackground(new Color(255, 0, 0));
		btnClearReport.setBounds(322, 227, 131, 23);
		panelUniversalOptions.add(btnClearReport);
		
		//Action Listeners
		
		comboBoxAnimal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//When a user selects a new animal or clicks the same animal again, all the values get reset
				textFieldBloodPressure.setText("");
				textFieldWeight.setText("");
				textFieldNumOfSpots.setText("");
				comboBoxDentalHealth.setSelectedIndex(-1);
				panelUniversalOptions.setVisible(true);
				//Hide all the animal specific fields and elements in case a new animal is selected
				lblBloodPressure.setVisible(false);
				textFieldBloodPressure.setVisible(false);
				lblNumOfSpots.setVisible(false);
				textFieldNumOfSpots.setVisible(false);
				lblDentalHealth.setVisible(false);
				comboBoxDentalHealth.setVisible(false);
				if(comboBoxAnimal.getSelectedIndex() == 0)
				{
					animal = new Penguin();
					currentAnimal = (Penguin) animal;
					lblBloodPressure.setVisible(true);
					textFieldBloodPressure.setVisible(true);
				}
				else if(comboBoxAnimal.getSelectedIndex() == 1)
				{
					animal = new Walrus();
					currentAnimal = (Walrus) animal;
					lblDentalHealth.setVisible(true);
					comboBoxDentalHealth.setVisible(true);
				}
				else if(comboBoxAnimal.getSelectedIndex() == 2)
				{
					animal = new SeaLion();
					currentAnimal = (SeaLion) animal;
					lblNumOfSpots.setVisible(true);
					textFieldNumOfSpots.setVisible(true);
				}
				
				comboBoxSex.setSelectedIndex(-1);
				textAreaGpsCoordinates.setText("");
			}
		});
		
		
		//Add GPS Coordinates
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//GPS Coordinate Validation
				String text = textFieldGpsCoordinates.getText();
				if(text.matches("[+-][0-9]{3}\\.[0-9]{7} {1}[+-][0-9]{3}\\.[0-9]{7}"))
				{
					currentAnimal.setCoordinates(text);
					String gps = "";
					gps += currentAnimal.getCoordinate(currentAnimal.coordinates.size() - 1) + "\n";
					textAreaGpsCoordinates.append(gps);
				}
				else 
				{
					JOptionPane.showMessageDialog(null, "Invalid GPS entry. \n Format is [+-]ddd.ddddddd [+-]ddd.ddddddd. \n Example: +012.1234567 -123.7654321");
				}
			}	
		});
		
		//Select sex
		comboBoxSex.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(comboBoxSex.getSelectedIndex()==0)
				{
					currentAnimal.setSex("male");
				}
				else if(comboBoxSex.getSelectedIndex()==1)
				{
					currentAnimal.setSex("female");
				}
				
				
			}
		});
		
		//Save entry
		btnSaveEntry.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//Inputs and Validations to set up the animal
				
				if(textFieldWeight.getText().matches("\\d*\\.?\\d+?")) //Matches double format
				{
					currentAnimal.setWeight(Double.parseDouble(textFieldWeight.getText()));
				}
				else 
				{
					JOptionPane.showMessageDialog(null, "Invalid weight entered");
				}
				
				if(currentAnimal.getClass().getName().equals("Penguin") && textFieldBloodPressure.getText().matches("\\d*\\.?\\d+?"))
				{
					((Penguin)currentAnimal).setBloodPressure(Double.parseDouble(textFieldBloodPressure.getText()));
				}
				else if(currentAnimal.getClass().getName().equals("Penguin"))
				{
					JOptionPane.showMessageDialog(null, "Invalid blood pressure entered.");
				}
				
				if(currentAnimal.getClass().getName().equals("Walrus") && comboBoxDentalHealth.getSelectedIndex() != -1)
				{
					((Walrus)currentAnimal).setDentalHealth(comboBoxDentalHealth.getSelectedIndex()); /*This setter is unique because it passes an index. The rest is taken care of in the walrus class*/
				}
				
				if(currentAnimal.getClass().getName().equals("SeaLion") && textFieldNumOfSpots.getText().matches("\\d*\\.?\\d+?"))
				{
					((SeaLion)currentAnimal).setNumOfSpots(Integer.parseInt(textFieldNumOfSpots.getText()));
				}
				
				else if(currentAnimal.getClass().getName().equals("SeaLion"))
				{
					JOptionPane.showMessageDialog(null, "Invalid number of spots entered");
				}
				
				
				//Validations for animal
				
				if(currentAnimal.getSex()==null)
				{
					JOptionPane.showMessageDialog(null, "You must select a sex for this animal");
				}
				else if (currentAnimal.getWeight() == 0.0) 
				{
					JOptionPane.showMessageDialog(null, "You must enter a weight for this animal");
				}
				else if (currentAnimal.getClass().getName().equals("Penguin") && ((Penguin)currentAnimal).getBloodPressure()==0.0) 
				{		
					JOptionPane.showMessageDialog(null, "You must enter blood pressure for the penguin");
				}
				else if (currentAnimal.getClass().getName().equals("Walrus") && ((Walrus)currentAnimal).getDentalHealth()==null) 
				{		
					JOptionPane.showMessageDialog(null, "You must enter one of three options for walrus's dental health");
				}
				else if (currentAnimal.getClass().getName().equals("SeaLion") && ((SeaLion)currentAnimal).getNumOfSpots()==0.0) 
				{		
					JOptionPane.showMessageDialog(null, "You must enter the number of spots on this sealion");
				}
				else
				{
					try { //Create the report
						fw = new FileWriter(inputFile, true); //Open connection to file. Adding true sets it to append mode
						String report = "";
						report += currentAnimal.getClass().getName() + ": Sex = " + currentAnimal.getSex() + ", Weight = " 
						+ currentAnimal.getWeight() + ", ";
						if(currentAnimal.getClass().getName().equals("Penguin"))
						{
							report += "Blood Pressure = " + ((Penguin)currentAnimal).getBloodPressure();
						}
						else if(currentAnimal.getClass().getName().equals("Walrus"))
						{
							report += "Dental Health: " + ((Walrus)currentAnimal).getDentalHealth();
						}
						else if(currentAnimal.getClass().getName().equals("SeaLion"))
						{
							report += "Number of spots = " + ((SeaLion)currentAnimal).getNumOfSpots();
						}
						
						report += ", Coordinates: " + currentAnimal.getCoordinates() + "\n"; //End of report for current animal. Adds line break so next animal takes its own line
					            
						fw.write(report);
						fw.close(); //The filewriter must be closed for the report to be written
						JOptionPane.showMessageDialog(null, "Animal saved to records file successfully");
					} catch (IOException e1) { //In case the file is not found
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}			
				}
			}
		});
		
		
		//Generate report
		btnGenerate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					fileInput = new Scanner(inputFile); //Use a scanner to read from the file
					String report = "";
					while(fileInput.hasNextLine())
					{
						report += fileInput.nextLine() + "\n";
					}
					fileInput.close(); //fileInput should be closed once we are done with it. 
					
					JOptionPane.showMessageDialog(null, report); //Shows a pop-up report of all animals in the records file
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			}
		});
		
		//Clear the report
		btnClearReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int response = JOptionPane.showConfirmDialog(null, "This will delete all animal records saved. Are you sure?", "Warning", JOptionPane.YES_NO_OPTION);
				if(response == JOptionPane.YES_OPTION)
				{
					try {
						fw = new FileWriter(inputFile);
						fw.write("");
						fw.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		});
	}	
}
