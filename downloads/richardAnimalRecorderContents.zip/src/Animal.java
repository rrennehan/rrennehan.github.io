//
import java.util.ArrayList;

public abstract class Animal {
	
	
	private final String[] sexes = {"male", "female"};
	private String sex;
	private double weight;
	ArrayList<ArrayList<String>> coordinates = new ArrayList<ArrayList<String>>();
	int arrayListCounter = 1;
	
	
	public Animal() {
		super();
	}


	public String getSex() {
		return sex;
	}


	public void setSex(String sex) {
		this.sex = sex;
	}


	public double getWeight() {
		return weight;
	}


	public void setWeight(double weight) {
		this.weight = weight;
	}


	public ArrayList<String> getCoordinate(int index) {
		return coordinates.get(index);
	}
	
	public ArrayList<ArrayList<String>> getCoordinates() {
		return coordinates;
	}

	//Add a coordinate to the arrayList rather than set entire list
	public void setCoordinates(String coordinates) {
		String coordinate1 = coordinates.substring(0, 12); //Grabs the first coordinate from the text input
		String coordinate2 = coordinates.substring(13, 25); //Pulls out second coordinate from text input.
		
		int counter = 0; //Counter for use with while loops
		while(true)
		{
			if((!coordinate1.substring(1,2).equals("0") || coordinate1.substring(2,3).equals(".")) && (!coordinate2.substring(1,2).equals("0") || coordinate2.substring(2,3).equals(".")))
			{
				break;
			}
			if(coordinate1.substring(1,2).equals("0") && !coordinate1.substring(2,3).equals("."))
			{
				coordinate1 = coordinate1.substring(0, 1) + coordinate1.substring(2, 12-counter); //Removes the zero
			}
			if(coordinate2.substring(1,2).equals("0") && !coordinate2.substring(2,3).equals("."))
			{
				coordinate2 = coordinate2.substring(0, 1) + coordinate2.substring(2, 12-counter);
			}
			counter += 1;
		}
		/*while(coordinate1.substring(1,2).equals("0") && !coordinate1.substring(2,3).equals(".")) //Checks for leading zeroes entered
		{
			coordinate1 = coordinate1.substring(0, 1) + coordinate1.substring(2, 12-counter); //Removes the zero
			counter += 1;	
		}
		
		counter = 0; //Resets the counter
		String coordinate2 = coordinates.substring(13, 25); //Pulls out second coordinate from text input. Repeats process for coordinate 1 below
		
		while(coordinate2.substring(1,2).equals("0") && !coordinate2.substring(2,3).equals("."))
		{
			coordinate2 = coordinate2.substring(0, 1) + coordinate2.substring(2, 12-counter);
			counter += 1;
		}*/
		
		this.coordinates.add(new ArrayList<String>()); //Adds new list inside 2d list to store the two paired values
		this.coordinates.get(arrayListCounter - 1).add(coordinate1); //Adds first coordinate
		this.coordinates.get(arrayListCounter - 1).add(coordinate2); //Adds second coordinate to make a pair
		arrayListCounter += 1; //Adds to the counter so the next run-through will add to the correct position automatically 
		
	}
	
	
	
	
}
